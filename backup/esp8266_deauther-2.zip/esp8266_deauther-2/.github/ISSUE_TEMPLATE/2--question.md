---
name: 2. Question
about: I have a question about this project
title: ""
labels: question
assignees: ''

---

> Please search for existing (open and closed) issues first to avoid duplicates.  
Also have a look at the [Wiki](https://github.com/spacehuhntech/esp8266_deauther/wiki).  
